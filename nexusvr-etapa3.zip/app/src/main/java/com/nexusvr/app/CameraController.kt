package com.nexusvr.app

import android.content.Context
import android.util.Size
import android.view.Surface
import androidx.camera.core.CameraSelector
import androidx.camera.core.ConcurrentCamera
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.UseCaseGroup
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Câmera frontal, traseira ou dupla (frontal + traseira ao mesmo tempo, se o aparelho suportar). */
class CameraController(private val context: Context, private val owner: LifecycleOwner) {

    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private var provider: ProcessCameraProvider? = null

    fun start(
        mode: Int,
        quality: Int,
        mainView: PreviewView,
        smallView: PreviewView?,
        onFrame: (ImageProxy, Boolean) -> Unit,
        onStarted: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                p.unbindAll()
                val rot = mainView.display?.rotation ?: Surface.ROTATION_0
                val name = if (mode == 2 && smallView != null) {
                    try {
                        startDual(p, mainView, smallView, quality, rot, onFrame)
                    } catch (e: Exception) {
                        p.unbindAll()
                        startSingle(p, 0, mainView, quality, rot, onFrame) + " (dupla não suportada aqui)"
                    }
                } else {
                    startSingle(p, mode, mainView, quality, rot, onFrame)
                }
                onStarted(name)
            } catch (e: Exception) {
                onError(e.message ?: "erro desconhecido na câmera")
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun stop() {
        provider?.unbindAll()
    }

    fun shutdown() {
        executor.shutdown()
    }

    private fun startSingle(
        p: ProcessCameraProvider,
        mode: Int,
        view: PreviewView,
        quality: Int,
        rot: Int,
        onFrame: (ImageProxy, Boolean) -> Unit
    ): String {
        val wantFront = mode != 1
        val front = if (p.hasCamera(selectorFor(wantFront))) wantFront else !wantFront
        val preview = previewUse(Size(1280, 720), view)
        val analysis = analysisUse(quality, front, rot, onFrame)
        p.bindToLifecycle(owner, selectorFor(front), preview, analysis)
        return if (front) "frontal" else "traseira"
    }

    private fun startDual(
        p: ProcessCameraProvider,
        main: PreviewView,
        small: PreviewView,
        quality: Int,
        rot: Int,
        onFrame: (ImageProxy, Boolean) -> Unit
    ): String {
        val supported = p.availableConcurrentCameraInfos.any { group ->
            group.any { it.lensFacing == CameraSelector.LENS_FACING_FRONT } &&
                group.any { it.lensFacing == CameraSelector.LENS_FACING_BACK }
        }
        if (!supported) throw IllegalStateException("celular sem suporte a duas câmeras ao mesmo tempo")
        val frontGroup = UseCaseGroup.Builder()
            .addUseCase(previewUse(Size(1280, 720), main))
            .addUseCase(analysisUse(quality, true, rot, onFrame))
            .build()
        val backGroup = UseCaseGroup.Builder()
            .addUseCase(previewUse(Size(640, 360), small))
            .build()
        p.bindToLifecycle(
            listOf(
                ConcurrentCamera.SingleCameraConfig(CameraSelector.DEFAULT_FRONT_CAMERA, frontGroup, owner),
                ConcurrentCamera.SingleCameraConfig(CameraSelector.DEFAULT_BACK_CAMERA, backGroup, owner)
            )
        )
        return "dupla (frontal + traseira)"
    }

    private fun selectorFor(front: Boolean): CameraSelector =
        if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA

    private fun previewUse(size: Size, view: PreviewView): Preview =
        Preview.Builder()
            .setResolutionSelector(selector(size))
            .build()
            .also { it.setSurfaceProvider(view.surfaceProvider) }

    private fun analysisUse(quality: Int, front: Boolean, rot: Int, onFrame: (ImageProxy, Boolean) -> Unit): ImageAnalysis {
        val size = when (quality) {
            0 -> Size(320, 240)
            1 -> Size(480, 360)
            else -> Size(640, 480)
        }
        val a = ImageAnalysis.Builder()
            .setResolutionSelector(selector(size))
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
            .build()
        a.targetRotation = rot
        a.setAnalyzer(executor) { proxy -> onFrame(proxy, front) }
        return a
    }

    private fun selector(size: Size): ResolutionSelector =
        ResolutionSelector.Builder()
            .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
            .setResolutionStrategy(
                ResolutionStrategy(size, ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
            )
            .build()
}
