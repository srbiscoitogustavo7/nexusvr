package com.nexusvr.app.ui

import android.content.Context
import android.graphics.Canvas
import android.view.View
import com.nexusvr.app.tracking.HandState

/** Desenha as mãos sobre a câmera (modo normal, sem VR). */
class HandOverlayView(context: Context) : View(context) {

    var style: Int = HandStyleRenderer.STYLE_SOLID
        set(v) {
            field = v
            invalidate()
        }

    private var hands: List<HandState> = emptyList()
    private var fw = 1
    private var fh = 1

    init {
        setWillNotDraw(false)
    }

    fun update(list: List<HandState>, w: Int, h: Int) {
        hands = list
        fw = maxOf(w, 1)
        fh = maxOf(h, 1)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        if (width == 0 || height == 0) return
        HandStyleRenderer.draw(c, hands, HandStyleRenderer.mapFor(width.toFloat(), height.toFloat(), fw, fh), style)
    }
}
