package com.nexusvr.app

import android.content.Context

/** Configurações salvas no aparelho. Cada opção altera o app de verdade. */
class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("nexus_settings", Context.MODE_PRIVATE)

    /** 0 = frontal, 1 = traseira, 2 = dupla (experimental). */
    var camera: Int
        get() = prefs.getInt("camera", 0)
        set(v) = prefs.edit().putInt("camera", v).apply()

    /** Índice em DisplayPresets.NAMES. */
    var display: Int
        get() = prefs.getInt("display", 0)
        set(v) = prefs.edit().putInt("display", v).apply()

    /** Distância entre os olhos em mm (55..75). Alinha as duas imagens no modo VR. */
    var ipdMm: Int
        get() = prefs.getInt("ipd", 63)
        set(v) = prefs.edit().putInt("ipd", v).apply()

    /** Campo de visão em graus (60..120). 90 = normal. */
    var fov: Int
        get() = prefs.getInt("fov", 90)
        set(v) = prefs.edit().putInt("fov", v).apply()

    /** Força da correção de lente, em centésimos (0..40). 0 = desligada. */
    var lensK: Int
        get() = prefs.getInt("lens_k", 22)
        set(v) = prefs.edit().putInt("lens_k", v).apply()

    /** 0 = pontos, 1 = ossos (esqueleto), 2 = mão sólida (estilo Quest), 3 = neon. */
    var handStyle: Int
        get() = prefs.getInt("hand_style", 2)
        set(v) = prefs.edit().putInt("hand_style", v).apply()

    /** 0 = fácil, 1 = normal, 2 = firme. */
    var pinchLevel: Int
        get() = prefs.getInt("pinch", 1)
        set(v) = prefs.edit().putInt("pinch", v).apply()

    /** 0 = economia (mais FPS), 1 = equilibrada, 2 = alta precisão. */
    var quality: Int
        get() = prefs.getInt("quality", 1)
        set(v) = prefs.edit().putInt("quality", v).apply()

    var showHud: Boolean
        get() = prefs.getBoolean("hud", true)
        set(v) = prefs.edit().putBoolean("hud", v).apply()
}

/** Modos de exibição. Os valores de lente são estimativas: ajuste no menu se a imagem não ficar boa. */
object DisplayPresets {
    val NAMES: List<String> = listOf("Tela normal (sem VR)", "VR Box 2.0", "VR Box 1.0", "Cardboard", "Óculos genérico")
    val SPLIT: BooleanArray = booleanArrayOf(false, true, true, true, true)
    val LENS_K: IntArray = intArrayOf(0, 22, 26, 30, 18)
}
