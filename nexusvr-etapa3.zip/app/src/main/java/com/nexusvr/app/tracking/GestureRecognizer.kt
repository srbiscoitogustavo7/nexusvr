package com.nexusvr.app.tracking

import kotlin.math.max
import kotlin.math.sqrt

/** Reconhece pinça, mão aberta, punho e apontar a partir dos 21 pontos da mão. */
class GestureRecognizer {
    private var on = 0.28f
    private var off = 0.40f
    private val pinching = HashMap<String, Boolean>()

    fun setLevel(level: Int) {
        when (level) {
            0 -> { on = 0.34f; off = 0.50f }
            2 -> { on = 0.22f; off = 0.32f }
            else -> { on = 0.28f; off = 0.40f }
        }
    }

    fun analyze(xs: FloatArray, ys: FloatArray, zs: FloatArray, label: String, frameW: Int, frameH: Int): HandState {
        fun d(a: Int, b: Int): Float {
            val dx = (xs[a] - xs[b]) * frameW
            val dy = (ys[a] - ys[b]) * frameH
            return sqrt(dx * dx + dy * dy)
        }

        val handSize = max(d(0, 9), 1f)
        val ratio = d(4, 8) / handSize
        val was = pinching[label] ?: false
        val now = if (was) ratio < off else ratio < on
        pinching[label] = now

        val fingers = booleanArrayOf(
            d(4, 17) > d(3, 17) * 1.05f,
            d(8, 0) > d(6, 0) * 1.08f,
            d(12, 0) > d(10, 0) * 1.08f,
            d(16, 0) > d(14, 0) * 1.08f,
            d(20, 0) > d(18, 0) * 1.08f
        )
        val four = fingers[1] && fingers[2] && fingers[3] && fingers[4]
        val none = !fingers[1] && !fingers[2] && !fingers[3] && !fingers[4]
        val onlyIndex = fingers[1] && !fingers[2] && !fingers[3] && !fingers[4]

        val gesture = when {
            now -> Gesture.PINCH
            four -> Gesture.OPEN_PALM
            none -> Gesture.FIST
            onlyIndex -> Gesture.POINT
            else -> Gesture.UNKNOWN
        }
        return HandState(xs, ys, zs, label, gesture, fingers, ratio, now && !was)
    }
}
