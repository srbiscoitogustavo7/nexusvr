package com.nexusvr.app.ui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import com.nexusvr.app.tracking.HandState

/** Estilos da mão: pontos, ossos (esqueleto), mão sólida (silhueta estilo Quest) e neon. */
object HandStyleRenderer {
    const val STYLE_POINTS = 0
    const val STYLE_BONES = 1
    const val STYLE_SOLID = 2
    const val STYLE_NEON = 3
    val NAMES: List<String> = listOf("Pontos e linhas", "Ossos (esqueleto)", "Mão sólida (estilo Quest)", "Neon")

    /** Mapeamento da imagem da câmera para a tela (mesmo corte do preview: preencher o centro). */
    class EyeMap(val fw: Int, val fh: Int, val mul: Float, val ox: Float, val oy: Float, val sw: Float)

    private val CONN = intArrayOf(
        0, 1, 1, 2, 2, 3, 3, 4, 0, 5, 5, 6, 6, 7, 7, 8, 5, 9, 9, 10, 10, 11, 11, 12,
        9, 13, 13, 14, 14, 15, 15, 16, 13, 17, 17, 18, 18, 19, 19, 20, 0, 17
    )
    private val FINGERS = arrayOf(
        intArrayOf(1, 2, 3, 4), intArrayOf(5, 6, 7, 8), intArrayOf(9, 10, 11, 12),
        intArrayOf(13, 14, 15, 16), intArrayOf(17, 18, 19, 20)
    )
    private val PALM = intArrayOf(0, 1, 5, 9, 13, 17)
    private val TIPS = intArrayOf(4, 8, 12, 16, 20)

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
    }
    private val path = Path()

    fun mapFor(w: Float, h: Float, fw: Int, fh: Int, shift: Float = 0f, zoom: Float = 1f): EyeMap {
        val mul = maxOf(w / fw, h / fh) * zoom
        val ox = (w - fw * mul) / 2f + shift
        val oy = (h - fh * mul) / 2f
        val sw = (minOf(w, h) / 720f).coerceIn(0.6f, 2.5f)
        return EyeMap(fw, fh, mul, ox, oy, sw)
    }

    fun draw(c: Canvas, hands: List<HandState>, m: EyeMap, style: Int) {
        for (h in hands) {
            when (style) {
                STYLE_BONES -> bones(c, m, h)
                STYLE_SOLID -> solid(c, m, h)
                STYLE_NEON -> neon(c, m, h)
                else -> points(c, m, h)
            }
        }
    }

    fun drawCursor(c: Canvas, x: Float, y: Float, pinch: Boolean, sw: Float) {
        if (pinch) {
            fill.color = 0xAA00E676.toInt()
            c.drawCircle(x, y, 22f * sw, fill)
        }
        ring.strokeWidth = 5f * sw
        c.drawCircle(x, y, (if (pinch) 22f else 32f) * sw, ring)
    }

    private fun px(m: EyeMap, h: HandState, i: Int) = h.xs[i] * m.fw * m.mul + m.ox
    private fun py(m: EyeMap, h: HandState, i: Int) = h.ys[i] * m.fh * m.mul + m.oy

    private fun segments(c: Canvas, m: EyeMap, h: HandState) {
        var i = 0
        while (i < CONN.size) {
            val a = CONN[i]
            val b = CONN[i + 1]
            c.drawLine(px(m, h, a), py(m, h, a), px(m, h, b), py(m, h, b), line)
            i += 2
        }
    }

    private fun points(c: Canvas, m: EyeMap, h: HandState) {
        line.color = 0xCC00E5FF.toInt()
        line.strokeWidth = 5f * m.sw
        line.clearShadowLayer()
        segments(c, m, h)
        fill.color = Color.WHITE
        for (i in 0 until 21) {
            c.drawCircle(px(m, h, i), py(m, h, i), (if (i in TIPS) 10f else 6f) * m.sw, fill)
        }
    }

    private fun bones(c: Canvas, m: EyeMap, h: HandState) {
        val dark = 0xFF1A1A1A.toInt()
        val bone = 0xFFF2EEE3.toInt()
        line.clearShadowLayer()
        line.color = dark
        line.strokeWidth = 17f * m.sw
        segments(c, m, h)
        line.color = bone
        line.strokeWidth = 9f * m.sw
        segments(c, m, h)
        fill.color = bone
        for (i in 0 until 21) {
            c.drawCircle(px(m, h, i), py(m, h, i), (if (i in TIPS) 11f else 7f) * m.sw, fill)
        }
    }

    private fun solid(c: Canvas, m: EyeMap, h: HandState) {
        silhouette(c, m, h, 0xFF2A3440.toInt(), 6f)
        silhouette(c, m, h, 0xDDB7CAD8.toInt(), 0f)
    }

    private fun silhouette(c: Canvas, m: EyeMap, h: HandState, color: Int, extra: Float) {
        path.reset()
        path.moveTo(px(m, h, PALM[0]), py(m, h, PALM[0]))
        for (k in 1 until PALM.size) path.lineTo(px(m, h, PALM[k]), py(m, h, PALM[k]))
        path.close()
        fill.color = color
        c.drawPath(path, fill)

        line.clearShadowLayer()
        line.color = color
        for (f in FINGERS) {
            for (k in 0 until f.size - 1) {
                line.strokeWidth = (26f - k * 5f + extra) * m.sw
                c.drawLine(px(m, h, f[k]), py(m, h, f[k]), px(m, h, f[k + 1]), py(m, h, f[k + 1]), line)
            }
        }
        for (t in TIPS) {
            c.drawCircle(px(m, h, t), py(m, h, t), (9f + extra / 2f) * m.sw, fill)
        }
    }

    private fun neon(c: Canvas, m: EyeMap, h: HandState) {
        val glow = 0xFF00E5FF.toInt()
        line.color = glow
        line.strokeWidth = 5f * m.sw
        line.setShadowLayer(14f * m.sw, 0f, 0f, glow)
        segments(c, m, h)
        line.clearShadowLayer()
        fill.color = 0xFFFF4081.toInt()
        for (t in TIPS) c.drawCircle(px(m, h, t), py(m, h, t), 8f * m.sw, fill)
    }
}
