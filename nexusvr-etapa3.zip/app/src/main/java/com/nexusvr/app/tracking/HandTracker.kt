package com.nexusvr.app.tracking

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult

/**
 * Rastreamento de duas mãos (MediaPipe, local e gratuito).
 * Desempenho: tenta a GPU do celular, descarta quadros enquanto o anterior ainda processa
 * e, no modo "economia", analisa só 1 quadro em cada 2.
 */
class HandTracker(context: Context, private val listener: Listener, var quality: Int) {

    interface Listener {
        fun onHands(hands: List<HandState>, frameW: Int, frameH: Int, fps: Int)
        fun onError(message: String)
    }

    /** Recebe cada quadro já girado (usado pelo modo VR). */
    @Volatile var frameSink: ((Bitmap) -> Unit)? = null

    var pinchLevel: Int = 1
        set(v) {
            field = v
            recognizer.setLevel(v)
        }

    private val recognizer = GestureRecognizer()
    val usingGpu: Boolean
    private val landmarker: HandLandmarker?
    private var counter = 0
    @Volatile private var pending = false
    @Volatile private var pendingSince = 0L
    @Volatile private var frameW = 1
    @Volatile private var frameH = 1
    private var windowStart = SystemClock.elapsedRealtime()
    private var windowCount = 0
    private var fps = 0

    init {
        var gpu = false
        var lm: HandLandmarker? = null
        try {
            lm = build(context, true)
            gpu = true
        } catch (e: Throwable) {
            try {
                lm = build(context, false)
            } catch (e2: Throwable) {
                listener.onError("Não foi possível iniciar o rastreamento de mãos: " + e2.message)
            }
        }
        landmarker = lm
        usingGpu = gpu
    }

    private fun build(context: Context, gpu: Boolean): HandLandmarker {
        val base = BaseOptions.builder().setModelAssetPath("hand_landmarker.task")
        if (gpu) base.setDelegate(Delegate.GPU)
        val options = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(base.build())
            .setNumHands(2)
            .setMinHandDetectionConfidence(0.5f)
            .setMinHandPresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setResultListener(this::onResult)
            .setErrorListener(this::onLandmarkerError)
            .build()
        return HandLandmarker.createFromOptions(context, options)
    }

    /** Recebe um quadro da câmera. Sempre fecha o ImageProxy. */
    fun analyze(image: ImageProxy, mirror: Boolean) {
        val lm = landmarker
        counter++
        val now = SystemClock.elapsedRealtime()
        val skip = quality == 0 && counter % 2 != 0
        val busy = pending && now - pendingSince < 250L
        if (lm == null || skip || busy) {
            image.close()
            return
        }
        try {
            val raw = image.toBitmap()
            val m = Matrix()
            m.postRotate(image.imageInfo.rotationDegrees.toFloat())
            if (mirror) m.postScale(-1f, 1f)
            val upright = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
            frameW = upright.width
            frameH = upright.height
            frameSink?.invoke(upright)
            pending = true
            pendingSince = now
            lm.detectAsync(BitmapImageBuilder(upright).build(), SystemClock.uptimeMillis())
        } catch (e: Throwable) {
            pending = false
            listener.onError("Erro ao analisar o quadro: " + e.message)
        } finally {
            image.close()
        }
    }

    private fun onResult(result: HandLandmarkerResult, input: MPImage) {
        pending = false
        val w = frameW
        val h = frameH
        val hands = ArrayList<HandState>()
        val marks = result.landmarks()
        val sides = result.handedness()
        for (i in marks.indices) {
            val lms = marks[i]
            if (lms.size < 21) continue
            val xs = FloatArray(21) { lms[it].x() }
            val ys = FloatArray(21) { lms[it].y() }
            val zs = FloatArray(21) { lms[it].z() }
            val label = if (i < sides.size && sides[i].isNotEmpty()) sides[i][0].categoryName() else "?"
            hands.add(recognizer.analyze(xs, ys, zs, label, w, h))
        }
        windowCount++
        val now = SystemClock.elapsedRealtime()
        if (now - windowStart >= 1000L) {
            fps = windowCount
            windowCount = 0
            windowStart = now
        }
        listener.onHands(hands, w, h, fps)
    }

    private fun onLandmarkerError(error: RuntimeException) {
        pending = false
        listener.onError("Erro do MediaPipe: " + error.message)
    }

    fun close() {
        try {
            landmarker?.close()
        } catch (_: Throwable) {
        }
    }
}
