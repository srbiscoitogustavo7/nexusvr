package com.nexusvr.app.tracking

enum class Gesture(val namePt: String) {
    OPEN_PALM("MÃO ABERTA"),
    PINCH("PINÇA"),
    FIST("PUNHO"),
    POINT("APONTAR"),
    UNKNOWN("-")
}

/**
 * Estado de uma mão detectada.
 * xs/ys/zs: 21 pontos normalizados (0..1) no quadro já girado e espelhado (igual ao preview).
 * fingers: [polegar, indicador, médio, anelar, mínimo] -> true se estendido.
 */
class HandState(
    val xs: FloatArray,
    val ys: FloatArray,
    val zs: FloatArray,
    val label: String,
    val gesture: Gesture,
    val fingers: BooleanArray,
    val pinchRatio: Float,
    val justPinched: Boolean
) {
    val labelPt: String
        get() = when (label) {
            "Left" -> "Esquerda"
            "Right" -> "Direita"
            else -> "Mão"
        }

    val cursorX: Float get() = xs[8]
    val cursorY: Float get() = ys[8]
}
