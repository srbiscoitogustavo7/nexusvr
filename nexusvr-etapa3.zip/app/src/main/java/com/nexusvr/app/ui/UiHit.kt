package com.nexusvr.app.ui

import android.view.View
import android.view.ViewGroup

/** Encontra o botão sob o cursor e dispara o clique (pinça = toque). */
object UiHit {
    fun clickAt(group: View, localX: Float, localY: Float): Boolean {
        val loc = IntArray(2)
        group.getLocationOnScreen(loc)
        val target = hit(group, loc[0] + localX, loc[1] + localY) ?: return false
        return target.performClick()
    }

    private fun hit(v: View, x: Float, y: Float): View? {
        if (v.visibility != View.VISIBLE) return null
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        if (x < loc[0] || y < loc[1] || x >= loc[0] + v.width || y >= loc[1] + v.height) return null
        if (v is ViewGroup) {
            for (i in v.childCount - 1 downTo 0) {
                val r = hit(v.getChildAt(i), x, y)
                if (r != null) return r
            }
        }
        return if (v.isClickable && v.isEnabled) v else null
    }
}
