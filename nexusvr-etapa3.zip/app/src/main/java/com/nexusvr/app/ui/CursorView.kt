package com.nexusvr.app.ui

import android.content.Context
import android.graphics.Canvas
import android.view.View

/** Cursor da mão (anel branco; fica verde ao pinçar). Não intercepta toques. */
class CursorView(context: Context) : View(context) {
    private var x = 0f
    private var y = 0f
    private var pinch = false
    private var on = false

    init {
        setWillNotDraw(false)
    }

    fun place(cx: Float, cy: Float, p: Boolean, show: Boolean) {
        x = cx
        y = cy
        pinch = p
        on = show
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        if (!on) return
        val sw = (minOf(width, height) / 720f).coerceIn(0.6f, 2.5f)
        HandStyleRenderer.drawCursor(c, x, y, pinch, sw)
    }
}
