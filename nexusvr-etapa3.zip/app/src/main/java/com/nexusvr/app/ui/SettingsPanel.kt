package com.nexusvr.app.ui

import android.content.Context
import android.graphics.Color
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import com.nexusvr.app.DisplayPresets
import com.nexusvr.app.SettingsStore

/** Tela de configurações. Tudo é pinçável: botões grandes, +/- e chaves. */
class SettingsPanel(
    context: Context,
    private val s: SettingsStore,
    private val onChanged: () -> Unit,
    private val onBack: () -> Unit
) : ScrollView(context) {

    private val content = LinearLayout(context)

    init {
        setBackgroundColor(0xF2070B14.toInt())
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(28), dp(24), dp(28), dp(40))
        addView(content)
        build()
    }

    fun refresh() = build()

    private fun build() {
        content.removeAllViews()
        title("CONFIGURAÇÕES")
        note("Tudo aplica na hora. Para abrir a barra de tarefas, mantenha o punho fechado parado por 1 segundo. Para clicar, faça a pinça sobre o botão.")

        section("Câmera")
        chips(listOf("Frontal", "Traseira", "Dupla (experimental)"), s.camera) {
            s.camera = it
            onChanged()
            build()
        }

        section("Modo de exibição")
        chips(DisplayPresets.NAMES, s.display) { i ->
            s.display = i
            s.lensK = DisplayPresets.LENS_K[i]
            onChanged()
            build()
        }

        section("Realidade (modo VR)")
        stepper("Distância interpupilar", 55, 75, 1, s.ipdMm, " mm") {
            s.ipdMm = it
            onChanged()
        }
        stepper("Campo de visão", 60, 120, 5, s.fov, "°") {
            s.fov = it
            onChanged()
        }
        stepper("Correção de lente (0 = desligada)", 0, 40, 2, s.lensK, "") {
            s.lensK = it
            onChanged()
        }

        section("Mãos")
        chips(HandStyleRenderer.NAMES, s.handStyle) {
            s.handStyle = it
            onChanged()
            build()
        }
        chips(listOf("Fácil", "Normal", "Firme"), s.pinchLevel) {
            s.pinchLevel = it
            onChanged()
            build()
        }

        section("Desempenho e bateria")
        chips(listOf("Economia (mais FPS)", "Equilibrada", "Alta precisão"), s.quality) {
            s.quality = it
            onChanged()
            build()
        }
        switchRow("Mostrar FPS e status", s.showHud) {
            s.showHud = it
            onChanged()
        }

        val back = Button(context)
        back.text = "VOLTAR"
        back.setBackgroundColor(0xFF1E88E5.toInt())
        back.setTextColor(Color.WHITE)
        back.setOnClickListener { onBack() }
        content.addView(
            back,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(70)).apply { topMargin = dp(20) }
        )
    }

    private fun title(t: String) {
        val v = TextView(context)
        v.text = t
        v.textSize = 30f
        v.setTextColor(Color.WHITE)
        content.addView(v)
    }

    private fun note(t: String) {
        val v = TextView(context)
        v.text = t
        v.textSize = 14f
        v.setTextColor(0xFF90A4AE.toInt())
        content.addView(v)
    }

    private fun section(t: String) {
        val v = TextView(context)
        v.text = t
        v.textSize = 19f
        v.setTextColor(0xFF4FC3F7.toInt())
        v.setPadding(0, dp(22), 0, dp(6))
        content.addView(v)
    }

    private fun chips(options: List<String>, selected: Int, onPick: (Int) -> Unit) {
        var row: LinearLayout? = null
        options.forEachIndexed { i, label ->
            if (i % 2 == 0) {
                val r = LinearLayout(context)
                r.orientation = LinearLayout.HORIZONTAL
                content.addView(r)
                row = r
            }
            val b = Button(context)
            b.text = label
            b.isAllCaps = false
            b.textSize = 14f
            b.setTextColor(Color.WHITE)
            b.setBackgroundColor(if (i == selected) 0xFF1E88E5.toInt() else 0xFF1B2433.toInt())
            b.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                .apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
            b.setOnClickListener { onPick(i) }
            row?.addView(b)
        }
    }

    private fun stepper(label: String, lo: Int, hi: Int, step: Int, value: Int, unit: String, onChange: (Int) -> Unit) {
        var current = value
        val caption = TextView(context)
        caption.setTextColor(Color.WHITE)
        caption.textSize = 16f
        caption.setPadding(0, dp(12), 0, dp(4))
        caption.text = "$label: $current$unit"

        fun change(delta: Int) {
            current = (current + delta).coerceIn(lo, hi)
            caption.text = "$label: $current$unit"
            onChange(current)
        }

        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(stepButton("−") { change(-step) })
        row.addView(stepButton("+") { change(step) })
        content.addView(caption)
        content.addView(row)
    }

    private fun stepButton(t: String, action: () -> Unit): Button {
        val b = Button(context)
        b.text = t
        b.textSize = 18f
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(0xFF1E88E5.toInt())
        b.layoutParams = LinearLayout.LayoutParams(dp(90), dp(56)).apply { setMargins(0, 0, dp(10), 0) }
        b.setOnClickListener { action() }
        return b
    }

    private fun switchRow(label: String, on: Boolean, onChange: (Boolean) -> Unit) {
        val sw = Switch(context)
        sw.text = label
        sw.setTextColor(Color.WHITE)
        sw.isChecked = on
        sw.setOnCheckedChangeListener { _, checked -> onChange(checked) }
        content.addView(sw)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
