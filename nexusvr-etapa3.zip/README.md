# NEXUS VR - Etapa 3

- Menu inicial sobre a câmera: INICIAR, CONFIGURAÇÕES, SAIR. Tudo funciona com a pinça.
- Cursor: a ponta do indicador controla o cursor; pinça clica.
- Punho fechado parado por 1 segundo abre a barra de tarefas (APPS e CONFIG).
  Só Configurações e Relógio funcionam; os demais aparecem como EM BREVE.
- Câmera: frontal, traseira ou dupla (experimental, depende do celular).
- Modos de exibição: tela normal, VR Box 2.0, VR Box 1.0, Cardboard e óculos genérico.
  Duas imagens lado a lado, com correção de lente e distância entre os olhos ajustáveis.
- Estilos de mão: pontos, ossos (esqueleto), mão sólida (estilo Quest, silhueta própria) e neon.
- Desempenho: GPU quando disponível, quadros descartados enquanto um quadro ainda processa,
  modo economia com 1 quadro em cada 2 e resolução menor. FPS aparece no status.

Ainda não existe: janelas flutuantes reais, aplicativos funcionando, rastreamento de posição da cabeça.
