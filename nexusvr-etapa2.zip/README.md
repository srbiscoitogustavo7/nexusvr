# NEXUS VR

## Etapa 1 (feita)
Base do app: projeto Gradle, CameraX, tela de configurações.

## Etapa 2 (esta versão): rastreamento de mãos
- Duas mãos, 21 pontos cada (MediaPipe HandLandmarker, local, gratuito).
- Dedos individuais (estendido/dobrado), gestos: pinça (clique), mão aberta, punho, apontar.
- Esqueleto e cursor desenhados sobre a câmera; HUD com FPS, mãos e cliques.
- O modelo hand_landmarker.task é baixado automaticamente durante o build.

## Ainda NÃO existe
Interface VR 3D, janelas flutuantes, sensores/headset (próximas etapas).

## Compilar
No PC: Android Studio > Build APK (precisa de internet no primeiro build).
Na nuvem: GitHub Actions (.github/workflows/build.yml).
