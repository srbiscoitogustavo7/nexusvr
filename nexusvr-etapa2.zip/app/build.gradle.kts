import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nexusvr.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nexusvr.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "0.2.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    androidResources {
        noCompress += listOf("task", "tflite")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")

    val cameraxVersion = "1.3.4"
    implementation("androidx.camera:camera-core:$cameraxVersion")
    implementation("androidx.camera:camera-camera2:$cameraxVersion")
    implementation("androidx.camera:camera-lifecycle:$cameraxVersion")
    implementation("androidx.camera:camera-view:$cameraxVersion")

    // Rastreamento de mãos (gratuito, roda 100% no aparelho)
    implementation("com.google.mediapipe:tasks-vision:0.10.14")
}

// Baixa o modelo gratuito de mãos do MediaPipe durante o build (se ainda não existir).
val handModelUrl =
    "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"

val downloadHandModel = tasks.register("downloadHandModel") {
    doLast {
        val target = file("src/main/assets/hand_landmarker.task")
        if (!target.exists() || target.length() < 1_000_000L) {
            target.parentFile.mkdirs()
            URL(handModelUrl).openStream().use { input ->
                target.outputStream().use { out -> input.copyTo(out) }
            }
        }
    }
}

tasks.named("preBuild") {
    dependsOn(downloadHandModel)
}
