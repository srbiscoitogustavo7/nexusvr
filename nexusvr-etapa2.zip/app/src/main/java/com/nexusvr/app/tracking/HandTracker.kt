package com.nexusvr.app.tracking

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult

/**
 * Rastreamento de duas mãos (21 pontos cada) usando MediaPipe HandLandmarker,
 * 100% local. O modelo fica em assets/hand_landmarker.task.
 */
class HandTracker(
    context: Context,
    private val listener: Listener
) {

    interface Listener {
        fun onHands(hands: List<HandState>, frameW: Int, frameH: Int, fps: Int)
        fun onError(message: String)
    }

    private var landmarker: HandLandmarker? = null
    private val recognizer = GestureRecognizer()

    @Volatile
    private var frameW = 1

    @Volatile
    private var frameH = 1

    private var windowStart = SystemClock.elapsedRealtime()
    private var windowCount = 0
    private var fps = 0

    init {
        try {
            val base = BaseOptions.builder()
                .setModelAssetPath("hand_landmarker.task")
                .build()
            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(base)
                .setNumHands(2)
                .setMinHandDetectionConfidence(0.5f)
                .setMinHandPresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setResultListener(this::onResult)
                .setErrorListener(this::onLandmarkerError)
                .build()
            landmarker = HandLandmarker.createFromOptions(context, options)
        } catch (e: Throwable) {
            listener.onError("Não foi possível iniciar o rastreamento de mãos: ${e.message}")
        }
    }

    /** Recebe um quadro da câmera. Sempre fecha o ImageProxy. */
    fun analyze(image: ImageProxy, mirror: Boolean) {
        val lm = landmarker
        if (lm == null) {
            image.close()
            return
        }
        try {
            val raw = image.toBitmap()
            val matrix = Matrix()
            matrix.postRotate(image.imageInfo.rotationDegrees.toFloat())
            if (mirror) matrix.postScale(-1f, 1f)
            val upright = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, matrix, true)
            frameW = upright.width
            frameH = upright.height
            val mpImage = BitmapImageBuilder(upright).build()
            lm.detectAsync(mpImage, SystemClock.uptimeMillis())
        } catch (e: Throwable) {
            listener.onError("Erro ao analisar o quadro: ${e.message}")
        } finally {
            image.close()
        }
    }

    private fun onResult(result: HandLandmarkerResult, input: MPImage) {
        val w = frameW
        val h = frameH
        val hands = ArrayList<HandState>()
        val allLandmarks = result.landmarks()
        val allHandedness = result.handedness()

        for (i in allLandmarks.indices) {
            val lms = allLandmarks[i]
            if (lms.size < 21) continue
            val xs = FloatArray(21) { lms[it].x() }
            val ys = FloatArray(21) { lms[it].y() }
            val zs = FloatArray(21) { lms[it].z() }
            val label = if (i < allHandedness.size && allHandedness[i].isNotEmpty()) {
                allHandedness[i][0].categoryName()
            } else {
                "?"
            }
            hands.add(recognizer.analyze(xs, ys, zs, label, w, h))
        }

        windowCount++
        val now = SystemClock.elapsedRealtime()
        if (now - windowStart >= 1000) {
            fps = windowCount
            windowCount = 0
            windowStart = now
        }
        listener.onHands(hands, w, h, fps)
    }

    private fun onLandmarkerError(error: RuntimeException) {
        listener.onError("Erro do MediaPipe: ${error.message}")
    }

    fun close() {
        try {
            landmarker?.close()
        } catch (_: Throwable) {
        }
        landmarker = null
    }
}
