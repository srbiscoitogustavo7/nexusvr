package com.nexusvr.app

import android.content.Context
import android.util.Size
import android.view.Surface
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Liga a câmera (frontal quando disponível) ao preview e à análise de quadros. */
class CameraController(
    private val context: Context,
    private val owner: LifecycleOwner
) {
    private val analysisExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    private fun selector(size: Size): ResolutionSelector =
        ResolutionSelector.Builder()
            .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
            .setResolutionStrategy(
                ResolutionStrategy(size, ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
            )
            .build()

    fun start(
        previewView: PreviewView,
        lowResolution: Boolean,
        onFrame: (ImageProxy, Boolean) -> Unit,
        onStarted: (Boolean) -> Unit,
        onError: (String) -> Unit
    ) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                val provider = future.get()

                val previewSize = if (lowResolution) Size(640, 360) else Size(1280, 720)
                val analysisSize = if (lowResolution) Size(480, 270) else Size(640, 360)

                val preview = Preview.Builder()
                    .setResolutionSelector(selector(previewSize))
                    .build()
                preview.setSurfaceProvider(previewView.surfaceProvider)

                val hasFront = provider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA)
                val cameraSelector = if (hasFront) {
                    CameraSelector.DEFAULT_FRONT_CAMERA
                } else {
                    CameraSelector.DEFAULT_BACK_CAMERA
                }

                val analysis = ImageAnalysis.Builder()
                    .setResolutionSelector(selector(analysisSize))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.targetRotation = previewView.display?.rotation ?: Surface.ROTATION_0
                analysis.setAnalyzer(analysisExecutor) { proxy -> onFrame(proxy, hasFront) }

                provider.unbindAll()
                provider.bindToLifecycle(owner, cameraSelector, preview, analysis)
                onStarted(hasFront)
            } catch (e: Exception) {
                onError(e.message ?: "erro desconhecido na câmera")
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun shutdown() {
        analysisExecutor.shutdown()
    }
}
