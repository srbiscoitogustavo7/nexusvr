package com.nexusvr.app.tracking

import kotlin.math.max
import kotlin.math.sqrt

/**
 * Reconhece gestos a partir dos 21 pontos da mão.
 * Pontos: 0 pulso; 4 ponta do polegar; 8 indicador; 12 médio; 16 anelar; 20 mínimo.
 */
class GestureRecognizer {

    private val pinching = HashMap<String, Boolean>()

    fun analyze(
        xs: FloatArray,
        ys: FloatArray,
        zs: FloatArray,
        label: String,
        frameW: Int,
        frameH: Int
    ): HandState {
        fun d(a: Int, b: Int): Float {
            val dx = (xs[a] - xs[b]) * frameW
            val dy = (ys[a] - ys[b]) * frameH
            return sqrt(dx * dx + dy * dy)
        }

        val handSize = max(d(0, 9), 1f)
        val ratio = d(4, 8) / handSize

        val was = pinching[label] ?: false
        val now = if (was) ratio < 0.40f else ratio < 0.28f
        pinching[label] = now

        val fingers = booleanArrayOf(
            d(4, 17) > d(3, 17) * 1.05f,
            d(8, 0) > d(6, 0) * 1.08f,
            d(12, 0) > d(10, 0) * 1.08f,
            d(16, 0) > d(14, 0) * 1.08f,
            d(20, 0) > d(18, 0) * 1.08f
        )

        val fourExtended = fingers[1] && fingers[2] && fingers[3] && fingers[4]
        val noneExtended = !fingers[1] && !fingers[2] && !fingers[3] && !fingers[4]
        val onlyIndex = fingers[1] && !fingers[2] && !fingers[3] && !fingers[4]

        val gesture = when {
            now -> Gesture.PINCH
            fourExtended -> Gesture.OPEN_PALM
            noneExtended -> Gesture.FIST
            onlyIndex -> Gesture.POINT
            else -> Gesture.UNKNOWN
        }

        return HandState(
            xs = xs,
            ys = ys,
            zs = zs,
            label = label,
            gesture = gesture,
            fingers = fingers,
            pinchRatio = ratio,
            justPinched = now && !was
        )
    }
}
