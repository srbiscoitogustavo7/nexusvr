package com.nexusvr.app.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import com.nexusvr.app.tracking.Gesture
import com.nexusvr.app.tracking.HandState
import kotlin.math.max

/** Desenha os 21 pontos de cada mão, o esqueleto e o cursor de pinça sobre o preview. */
class HandOverlayView(context: Context) : View(context) {

    private var hands: List<HandState> = emptyList()
    private var frameW = 1
    private var frameH = 1

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xCC00E5FF.toInt()
        strokeWidth = 6f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val pointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val tipPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFF4081.toInt()
        style = Paint.Style.FILL
    }
    private val cursorRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }
    private val cursorFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xAA00E676.toInt()
        style = Paint.Style.FILL
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 36f
        setShadowLayer(6f, 0f, 0f, Color.BLACK)
    }

    init {
        setWillNotDraw(false)
    }

    fun update(newHands: List<HandState>, w: Int, h: Int) {
        hands = newHands
        frameW = max(w, 1)
        frameH = max(h, 1)
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width == 0 || height == 0) return

        // Mesmo mapeamento do PreviewView em FILL_CENTER.
        val scale = max(width / frameW.toFloat(), height / frameH.toFloat())
        val offX = (width - frameW * scale) / 2f
        val offY = (height - frameH * scale) / 2f

        for (hand in hands) {
            fun px(i: Int) = hand.xs[i] * frameW * scale + offX
            fun py(i: Int) = hand.ys[i] * frameH * scale + offY

            var c = 0
            while (c < CONNECTIONS.size) {
                val a = CONNECTIONS[c]
                val b = CONNECTIONS[c + 1]
                canvas.drawLine(px(a), py(a), px(b), py(b), linePaint)
                c += 2
            }

            for (i in 0 until 21) {
                val isTip = i == 4 || i == 8 || i == 12 || i == 16 || i == 20
                canvas.drawCircle(px(i), py(i), if (isTip) 11f else 7f, if (isTip) tipPaint else pointPaint)
            }

            // Cursor na ponta do indicador.
            val cx = px(8)
            val cy = py(8)
            if (hand.gesture == Gesture.PINCH) {
                canvas.drawCircle(cx, cy, 30f, cursorFill)
            }
            canvas.drawCircle(cx, cy, 30f, cursorRing)

            canvas.drawText("${hand.labelPt}: ${hand.gesture.namePt}", px(0) - 60f, py(0) + 50f, textPaint)
        }
    }

    companion object {
        // Pares (a, b) achatados: conexões do esqueleto da mão.
        private val CONNECTIONS = intArrayOf(
            0, 1, 1, 2, 2, 3, 3, 4,
            0, 5, 5, 6, 6, 7, 7, 8,
            5, 9, 9, 10, 10, 11, 11, 12,
            9, 13, 13, 14, 14, 15, 15, 16,
            13, 17, 17, 18, 18, 19, 19, 20,
            0, 17
        )
    }
}
