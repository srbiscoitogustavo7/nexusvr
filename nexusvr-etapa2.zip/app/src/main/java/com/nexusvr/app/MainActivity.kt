package com.nexusvr.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.nexusvr.app.tracking.HandState
import com.nexusvr.app.tracking.HandTracker
import com.nexusvr.app.ui.HandOverlayView

class MainActivity : AppCompatActivity() {

    private lateinit var settings: SettingsStore
    private lateinit var camera: CameraController
    private lateinit var tracker: HandTracker
    private lateinit var previewView: PreviewView
    private lateinit var overlay: HandOverlayView
    private lateinit var status: TextView

    private var cameraName = "-"
    private var clicks = 0
    private var frameCounter = 0

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                startCamera()
            } else {
                status.text = "NEXUS VR\nPermissão da câmera negada. Ative nas configurações do Android."
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = SettingsStore(this)
        camera = CameraController(this, this)

        previewView = PreviewView(this)
        previewView.scaleType = PreviewView.ScaleType.FILL_CENTER

        overlay = HandOverlayView(this)

        status = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(0x99000000.toInt())
            setPadding(24, 16, 24, 16)
            textSize = 13f
            text = "NEXUS VR - Etapa 2\nIniciando câmera e rastreamento..."
        }

        val settingsButton = Button(this).apply {
            text = "Configurações"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
            }
        }

        val root = FrameLayout(this)
        val match = FrameLayout.LayoutParams.MATCH_PARENT
        val wrap = FrameLayout.LayoutParams.WRAP_CONTENT
        root.addView(previewView, FrameLayout.LayoutParams(match, match))
        root.addView(overlay, FrameLayout.LayoutParams(match, match))
        root.addView(status, FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.START))
        root.addView(settingsButton, FrameLayout.LayoutParams(wrap, wrap, Gravity.BOTTOM or Gravity.END))
        setContentView(root)

        tracker = HandTracker(this, object : HandTracker.Listener {
            override fun onHands(hands: List<HandState>, frameW: Int, frameH: Int, fps: Int) {
                runOnUiThread {
                    overlay.update(hands, frameW, frameH)
                    clicks += hands.count { it.justPinched }
                    updateHud(hands, fps)
                }
            }

            override fun onError(message: String) {
                runOnUiThread { status.text = "NEXUS VR\n$message" }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) {
            startCamera()
        } else {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        tracker.close()
        camera.shutdown()
    }

    private fun startCamera() {
        val low = settings.lowPerformance
        camera.start(
            previewView = previewView,
            lowResolution = low,
            onFrame = { proxy, front ->
                frameCounter++
                if (low && frameCounter % 2 == 0) {
                    proxy.close()
                } else {
                    tracker.analyze(proxy, front)
                }
            },
            onStarted = { front ->
                cameraName = if (front) "frontal" else "traseira"
                updateHud(emptyList(), 0)
            },
            onError = { msg ->
                status.text = "NEXUS VR\nErro na câmera: $msg"
            }
        )
    }

    private fun updateHud(hands: List<HandState>, fps: Int) {
        val sb = StringBuilder()
        sb.append("NEXUS VR - Etapa 2\n")
        sb.append("Câmera: ").append(cameraName)
        sb.append(" | Rastreamento: ").append(fps).append(" FPS")
        sb.append(" | Mãos: ").append(hands.size)
        sb.append(" | Cliques (pinça): ").append(clicks)
        if (hands.isEmpty()) {
            sb.append("\nMostre as mãos para a câmera frontal.")
        }
        for (hand in hands) {
            sb.append("\n").append(hand.labelPt).append(": ").append(hand.gesture.namePt)
            sb.append("  dedos [")
            for (i in hand.fingers.indices) {
                sb.append(if (hand.fingers[i]) "1" else "0")
                if (i < hand.fingers.size - 1) sb.append(" ")
            }
            sb.append("]")
        }
        status.text = sb.toString()
    }
}
