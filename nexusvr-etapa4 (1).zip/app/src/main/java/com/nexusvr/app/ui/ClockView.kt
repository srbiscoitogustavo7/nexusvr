package com.nexusvr.app.ui

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Conteúdo da janela Relógio (hora e data reais do aparelho). */
class ClockView(context: Context) : TextView(context) {

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val dateFmt = SimpleDateFormat("EEEE, dd 'de' MMMM", Locale.getDefault())
    private val tick = object : Runnable {
        override fun run() {
            update()
            postDelayed(this, 1000L)
        }
    }

    init {
        setTextColor(Color.WHITE)
        textSize = 30f
        gravity = Gravity.CENTER
        minimumWidth = (300 * resources.displayMetrics.density).toInt()
        update()
    }

    private fun update() {
        val now = Date()
        text = timeFmt.format(now) + "\n" + dateFmt.format(now)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        post(tick)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        removeCallbacks(tick)
    }
}
