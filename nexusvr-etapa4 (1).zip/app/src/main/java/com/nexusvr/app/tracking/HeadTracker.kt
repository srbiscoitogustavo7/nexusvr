package com.nexusvr.app.tracking

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.asin
import kotlin.math.atan2

/**
 * Orientação da cabeça pelo giroscópio (rotation vector de jogo, sem bússola).
 * Usa a direção da câmera traseira do celular: não trava quando o celular está em pé (VR Box).
 * yaw aumenta ao virar a cabeça para a direita; pitch aumenta ao olhar para cima. Em graus.
 */
class HeadTracker(context: Context) : SensorEventListener {

    private val manager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val sensor: Sensor? = manager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
    private val rot = FloatArray(9)
    private var rawYaw = 0f
    private var rawPitch = 0f
    private var centerYaw = 0f
    private var centerPitch = 0f
    private var first = true

    val available: Boolean get() = sensor != null
    var sensitivity = 1f
    var onChange: ((Float, Float) -> Unit)? = null

    fun start() {
        manager.unregisterListener(this)
        sensor?.let { manager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    fun stop() {
        manager.unregisterListener(this)
    }

    /** Define a direção atual como "frente". */
    fun recenter() {
        centerYaw = rawYaw
        centerPitch = rawPitch
    }

    override fun onSensorChanged(event: SensorEvent) {
        SensorManager.getRotationMatrixFromVector(rot, event.values)
        val east = -rot[2]
        val north = -rot[5]
        val up = (-rot[8]).coerceIn(-1f, 1f)
        rawYaw = Math.toDegrees(atan2(east.toDouble(), north.toDouble())).toFloat()
        rawPitch = Math.toDegrees(asin(up.toDouble())).toFloat()
        if (first) {
            first = false
            recenter()
        }
        val yaw = wrap(rawYaw - centerYaw) * sensitivity
        val pitch = (rawPitch - centerPitch) * sensitivity
        onChange?.invoke(yaw, pitch)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun wrap(a: Float): Float {
        var d = a
        while (d > 180f) d -= 360f
        while (d < -180f) d += 360f
        return d
    }
}
