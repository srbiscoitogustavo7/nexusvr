package com.nexusvr.app.ui

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Janela flutuante. Arraste pela barra de título (com o dedo ou com a pinça),
 * use − e + para mudar o tamanho e X para fechar.
 * ax/ay = posição em graus no "mundo" (usada pelo WindowHost).
 */
class FloatingWindow(context: Context, val kind: String, title: String, content: View) : LinearLayout(context) {

    var ax = 0f
    var ay = 0f
    var onClose: ((FloatingWindow) -> Unit)? = null
    var onResized: (() -> Unit)? = null
    var onDragBy: ((FloatingWindow, Float, Float) -> Unit)? = null

    private val scales = floatArrayOf(0.6f, 0.8f, 1.0f, 1.3f, 1.6f, 1.9f)
    private var level = 2
    private var lastX = 0f
    private var lastY = 0f

    init {
        orientation = VERTICAL
        background = GradientDrawable().apply {
            setColor(0xEE101826.toInt())
            cornerRadius = dp(18).toFloat()
        }

        val bar = LinearLayout(context)
        bar.orientation = HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.tag = "drag"
        bar.setPadding(dp(14), dp(6), dp(8), dp(6))

        val t = TextView(context)
        t.text = title
        t.textSize = 16f
        t.setTextColor(Color.WHITE)
        bar.addView(t, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(smallButton("−") { change(-1) })
        bar.addView(smallButton("+") { change(1) })
        bar.addView(smallButton("X") { onClose?.invoke(this) })
        bar.setOnTouchListener { _, e -> touch(e) }
        addView(bar)

        content.setPadding(dp(18), dp(10), dp(18), dp(18))
        addView(content)
        applyScale()
    }

    private fun touch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.rawX
                lastY = e.rawY
            }
            MotionEvent.ACTION_MOVE -> {
                onDragBy?.invoke(this, e.rawX - lastX, e.rawY - lastY)
                lastX = e.rawX
                lastY = e.rawY
            }
        }
        return true
    }

    private fun change(delta: Int) {
        level = (level + delta).coerceIn(0, scales.size - 1)
        applyScale()
    }

    private fun applyScale() {
        scaleX = scales[level]
        scaleY = scales[level]
        onResized?.invoke()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        pivotX = w / 2f
        pivotY = h / 2f
    }

    private fun smallButton(label: String, action: () -> Unit): Button {
        val b = Button(context)
        b.text = label
        b.textSize = 16f
        b.setTextColor(Color.WHITE)
        b.background = GradientDrawable().apply {
            setColor(0xFF243247.toInt())
            cornerRadius = dp(12).toFloat()
        }
        b.layoutParams = LayoutParams(dp(54), dp(48)).apply { setMargins(dp(4), 0, 0, 0) }
        b.setOnClickListener { action() }
        return b
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
