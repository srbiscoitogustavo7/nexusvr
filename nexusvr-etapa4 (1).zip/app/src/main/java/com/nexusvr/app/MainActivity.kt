package com.nexusvr.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.nexusvr.app.tracking.HandState
import com.nexusvr.app.tracking.HandTracker
import com.nexusvr.app.tracking.HeadTracker
import com.nexusvr.app.tracking.InputController
import com.nexusvr.app.ui.ClockView
import com.nexusvr.app.ui.CursorView
import com.nexusvr.app.ui.DockBar
import com.nexusvr.app.ui.FloatingWindow
import com.nexusvr.app.ui.HandOverlayView
import com.nexusvr.app.ui.SettingsPanel
import com.nexusvr.app.ui.UiHit
import com.nexusvr.app.ui.VrStereoView
import com.nexusvr.app.ui.WindowHost

/** Menu, realidade mista, modo VR, janelas flutuantes e configurações. A câmera fica ligada em todas as telas. */
class MainActivity : AppCompatActivity(), HandTracker.Listener {

    private lateinit var settings: SettingsStore
    private lateinit var camera: CameraController
    private lateinit var tracker: HandTracker
    private lateinit var head: HeadTracker
    private lateinit var input: InputController
    private lateinit var root: FrameLayout
    private lateinit var previewMain: PreviewView
    private lateinit var previewSmall: PreviewView
    private lateinit var handOverlay: HandOverlayView
    private lateinit var stereo: VrStereoView
    private lateinit var cursorView: CursorView
    private lateinit var uiLayer: FrameLayout
    private lateinit var menuPanel: LinearLayout
    private lateinit var settingsPanel: SettingsPanel
    private lateinit var windowHost: WindowHost
    private lateinit var dock: DockBar
    private lateinit var status: TextView
    private lateinit var menuButton: Button

    private var inCamera = false
    private var vrOn = false
    private var uiBitmap: Bitmap? = null
    private var camName = "-"
    private var engineName = "..."
    private var lastError = ""
    private var fps = 0
    private var handsNow = 0
    private var gestures = ""
    private var lastCamera = -1
    private var lastQuality = -1
    private var dragWin: FloatingWindow? = null
    private var grabDx = 0f
    private var grabDy = 0f

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            startCamera()
        } else {
            lastError = "Permissão da câmera negada. Ative nas configurações do Android."
            updateStatus()
        }
    }

    private val uiTicker = object : Runnable {
        override fun run() {
            if (!vrOn) return
            snapshotUi()
            root.postDelayed(this, 66L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val bars = WindowInsetsControllerCompat(window, window.decorView)
        bars.hide(WindowInsetsCompat.Type.systemBars())
        bars.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        settings = SettingsStore(this)
        camera = CameraController(this, this)
        head = HeadTracker(this)
        buildViews()
        head.onChange = { yaw, pitch -> windowHost.setHead(yaw, pitch) }
        tracker = HandTracker(this, this, settings.quality)
        engineName = if (tracker.usingGpu) "GPU" else "CPU"
        input = InputController(
            onPinchStart = { x, y -> pinchStart(x, y) },
            onPinchMove = { x, y -> pinchMove(x, y) },
            onPinchEnd = { dragWin = null },
            onFistHold = { toggleDock() }
        )
        applySettings()
    }

    override fun onResume() {
        super.onResume()
        startCamera()
        if (settings.headTracking) head.start()
    }

    override fun onPause() {
        super.onPause()
        camera.stop()
        head.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        tracker.close()
        camera.shutdown()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun matchParent() = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)

    private fun wrap(gravity: Int, margin: Int) =
        FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, gravity)
            .apply { setMargins(margin, margin, margin, margin) }

    private fun buildViews() {
        root = FrameLayout(this)
        previewMain = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        previewSmall = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            visibility = View.GONE
        }
        handOverlay = HandOverlayView(this)
        stereo = VrStereoView(this).apply { visibility = View.GONE }
        cursorView = CursorView(this)
        uiLayer = FrameLayout(this)

        val pip = (resources.displayMetrics.widthPixels * 0.26f).toInt()
        root.addView(previewMain, matchParent())
        root.addView(
            previewSmall,
            FrameLayout.LayoutParams(pip, pip * 3 / 4, Gravity.BOTTOM or Gravity.START)
                .apply { setMargins(dp(16), dp(16), dp(16), dp(16)) }
        )
        root.addView(handOverlay, matchParent())
        root.addView(uiLayer, matchParent())
        root.addView(stereo, matchParent())
        root.addView(cursorView, matchParent())
        setContentView(root)

        menuPanel = buildMenu()
        settingsPanel = SettingsPanel(this, settings, { onSettingsChanged() }, { head.recenter() }, { closeSettings() })
        settingsPanel.visibility = View.GONE
        windowHost = WindowHost(this)
        dock = DockBar(this, { openSettings() }, { kind -> openWindow(kind) }, { head.recenter() })
        dock.visibility = View.GONE
        status = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 13f
            setBackgroundColor(0xAA000000.toInt())
            setPadding(dp(12), dp(8), dp(12), dp(8))
            visibility = View.GONE
        }
        menuButton = Button(this).apply {
            text = "MENU"
            visibility = View.GONE
            setOnClickListener { goMenu() }
        }

        uiLayer.addView(menuPanel, matchParent())
        uiLayer.addView(settingsPanel, matchParent())
        uiLayer.addView(windowHost, matchParent())
        uiLayer.addView(status, wrap(Gravity.TOP or Gravity.START, dp(12)))
        uiLayer.addView(menuButton, wrap(Gravity.TOP or Gravity.END, dp(12)))
        uiLayer.addView(dock, wrap(Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, dp(16)))
    }

    private fun buildMenu(): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.setBackgroundColor(0xB8070B14.toInt())

        val title = TextView(this)
        title.text = "NEXUS VR"
        title.textSize = 44f
        title.setTextColor(Color.WHITE)
        title.gravity = Gravity.CENTER
        box.addView(title)

        val sub = TextView(this)
        sub.text = "Realidade mista pelo celular"
        sub.textSize = 16f
        sub.setTextColor(0xFF90A4AE.toInt())
        sub.gravity = Gravity.CENTER
        sub.setPadding(0, 0, 0, dp(24))
        box.addView(sub)

        box.addView(menuItem("INICIAR REALIDADE MISTA") { startCameraMode() })
        box.addView(menuItem("CONFIGURAÇÕES") { openSettings() })
        box.addView(menuItem("SAIR") { finish() })
        return box
    }

    private fun menuItem(label: String, action: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.setOnClickListener { action() }
        b.layoutParams = LinearLayout.LayoutParams(dp(420), dp(64)).apply { setMargins(0, dp(8), 0, dp(8)) }
        return b
    }

    private fun startCameraMode() {
        inCamera = true
        menuPanel.visibility = View.GONE
        menuButton.visibility = View.VISIBLE
        applySettings()
    }

    private fun goMenu() {
        inCamera = false
        dock.visibility = View.GONE
        menuButton.visibility = View.GONE
        menuPanel.visibility = View.VISIBLE
        applySettings()
    }

    private fun openSettings() {
        settingsPanel.refresh()
        menuPanel.visibility = View.GONE
        dock.visibility = View.GONE
        windowHost.visibility = View.GONE
        settingsPanel.visibility = View.VISIBLE
    }

    private fun closeSettings() {
        settingsPanel.visibility = View.GONE
        if (!inCamera) menuPanel.visibility = View.VISIBLE
        applySettings()
    }

    private fun toggleDock() {
        if (!inCamera || settingsPanel.visibility == View.VISIBLE) return
        dock.visibility = if (dock.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        dock.refreshClock()
    }

    private fun openWindow(kind: String) {
        if (kind == "clock") windowHost.open("clock", "Relógio") { ClockView(this) }
    }

    private fun onSettingsChanged() {
        val needRestart = lastCamera != settings.camera || lastQuality != settings.quality
        applySettings()
        if (needRestart) startCamera()
    }

    private fun applySettings() {
        vrOn = inCamera && DisplayPresets.SPLIT[settings.display]
        handOverlay.style = settings.handStyle
        stereo.style = settings.handStyle
        stereo.ipdMm = settings.ipdMm
        stereo.zoom = 90f / settings.fov
        stereo.lensK = settings.lensK / 100f
        tracker.pinchLevel = settings.pinchLevel
        tracker.quality = settings.quality
        val sink: (Bitmap) -> Unit = { b -> stereo.setFrame(b) }
        tracker.frameSink = if (vrOn) sink else null

        head.sensitivity = settings.headSens / 100f
        if (settings.headTracking) {
            head.start()
        } else {
            head.stop()
            windowHost.setHead(0f, 0f)
        }
        windowHost.fov = settings.fov
        windowHost.anchored = settings.worldLock && settings.headTracking && head.available
        windowHost.visibility = if (inCamera && settingsPanel.visibility != View.VISIBLE) View.VISIBLE else View.GONE

        previewSmall.visibility = if (settings.camera == 2) View.VISIBLE else View.GONE
        stereo.visibility = if (vrOn) View.VISIBLE else View.GONE
        cursorView.visibility = if (vrOn) View.GONE else View.VISIBLE
        root.removeCallbacks(uiTicker)
        if (vrOn) root.post(uiTicker)
        updateStatus()
    }

    private fun startCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
            return
        }
        lastCamera = settings.camera
        lastQuality = settings.quality
        camera.start(
            mode = settings.camera,
            quality = settings.quality,
            mainView = previewMain,
            smallView = previewSmall,
            onFrame = { proxy, front -> tracker.analyze(proxy, front) },
            onStarted = { name ->
                camName = name
                lastError = ""
                updateStatus()
            },
            onError = { msg ->
                lastError = msg
                updateStatus()
            }
        )
    }

    override fun onHands(hands: List<HandState>, frameW: Int, frameH: Int, fps: Int) {
        runOnUiThread { onHandsUi(hands, frameW, frameH, fps) }
    }

    override fun onError(message: String) {
        runOnUiThread {
            lastError = message
            updateStatus()
        }
    }

    /** Largura da área visível para o cursor: um olho inteiro no modo VR, a tela toda no modo normal. */
    private fun viewW(): Float = if (vrOn) root.width / 2f else root.width.toFloat()

    private fun toRootX(x: Float): Float = x * root.width / viewW()

    private fun pinchStart(x: Float, y: Float) {
        val rx = toRootX(x)
        val v = UiHit.viewAt(uiLayer, rx, y) ?: return
        if (v.tag == "drag") {
            val w = v.parent as? FloatingWindow ?: return
            dragWin = w
            grabDx = rx - windowHost.centerX(w)
            grabDy = y - windowHost.centerY(w)
        } else {
            v.performClick()
        }
    }

    private fun pinchMove(x: Float, y: Float) {
        val w = dragWin ?: return
        windowHost.dragTo(w, toRootX(x) - grabDx, y - grabDy)
    }

    private fun onHandsUi(hands: List<HandState>, fw: Int, fh: Int, fpsNow: Int) {
        fps = fpsNow
        handsNow = hands.size
        gestures = hands.joinToString("   ") { it.labelPt + ": " + it.gesture.namePt }
        handOverlay.update(hands, fw, fh)
        stereo.hands = hands
        stereo.fw = fw
        stereo.fh = fh
        val zoom = if (vrOn) stereo.zoom else 1f
        input.update(hands, fw, fh, viewW(), root.height.toFloat(), zoom)
        cursorView.place(input.cursorX, input.cursorY, input.pinching, input.visible)
        stereo.setCursor(input.cursorX, input.cursorY, input.pinching, input.visible)
        if (vrOn) stereo.invalidate()
        updateStatus()
    }

    private fun updateStatus() {
        val show = inCamera && (settings.showHud || lastError.isNotEmpty())
        status.visibility = if (show) View.VISIBLE else View.GONE
        if (!show) return
        val headInfo = when {
            !head.available -> "sem giroscópio"
            settings.headTracking -> "ligada"
            else -> "desligada"
        }
        val t = StringBuilder()
        t.append("NEXUS VR - Etapa 4   |   ").append(DisplayPresets.NAMES[settings.display]).append('\n')
        t.append("Câmera: ").append(camName)
            .append("   |   FPS: ").append(fps)
            .append("   |   Mãos: ").append(handsNow)
            .append("   |   Motor: ").append(engineName)
            .append("   |   Cabeça: ").append(headInfo).append('\n')
        if (gestures.isNotEmpty()) t.append(gestures).append('\n')
        if (lastError.isNotEmpty()) t.append("Aviso: ").append(lastError)
        status.text = t.toString()
    }

    /** Foto da interface (menus, barra, janelas) em meia resolução para aparecer dentro dos dois olhos. */
    private fun snapshotUi() {
        val w = uiLayer.width / 2
        val h = uiLayer.height / 2
        if (w <= 0 || h <= 0) return
        var bmp = uiBitmap
        if (bmp == null || bmp.width != w || bmp.height != h) {
            bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            uiBitmap = bmp
        }
        bmp.eraseColor(Color.TRANSPARENT)
        val c = Canvas(bmp)
        c.scale(0.5f, 0.5f)
        uiLayer.draw(c)
        stereo.ui = bmp
    }
}
