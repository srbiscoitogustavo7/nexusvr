package com.nexusvr.app.tracking

import android.os.SystemClock
import com.nexusvr.app.ui.HandStyleRenderer
import kotlin.math.hypot

/**
 * Transforma a mão em cursor. Pinça: começa, move (arrastar) e termina.
 * Punho fechado parado por 1,1 s abre a barra de tarefas.
 * O cursor fica no espaço da área visível (um olho inteiro no modo VR).
 */
class InputController(
    private val onPinchStart: (Float, Float) -> Unit,
    private val onPinchMove: (Float, Float) -> Unit,
    private val onPinchEnd: () -> Unit,
    private val onFistHold: () -> Unit
) {
    var cursorX = 0f
    var cursorY = 0f
    var visible = false
    var pinching = false

    private var wasPinching = false
    private var fistX = 0f
    private var fistY = 0f
    private var fistSince = 0L
    private var lastHold = 0L

    fun update(hands: List<HandState>, fw: Int, fh: Int, vw: Float, vh: Float, zoom: Float) {
        if (hands.isEmpty() || vw <= 0f) {
            visible = false
            pinching = false
            fistSince = 0L
            endPinch()
            return
        }
        val map = HandStyleRenderer.mapFor(vw, vh, fw, fh, 0f, zoom)
        val pointer = hands.firstOrNull { it.gesture != Gesture.FIST } ?: hands[0]
        val tx = pointer.xs[8] * fw * map.mul + map.ox
        val ty = pointer.ys[8] * fh * map.mul + map.oy
        if (visible) {
            cursorX += (tx - cursorX) * 0.5f
            cursorY += (ty - cursorY) * 0.5f
        } else {
            cursorX = tx
            cursorY = ty
        }
        visible = true
        pinching = pointer.gesture == Gesture.PINCH
        if (pinching) {
            if (!wasPinching) onPinchStart(cursorX, cursorY) else onPinchMove(cursorX, cursorY)
            wasPinching = true
        } else {
            endPinch()
        }

        val fist = hands.firstOrNull { it.gesture == Gesture.FIST }
        val now = SystemClock.elapsedRealtime()
        if (fist == null) {
            fistSince = 0L
            return
        }
        val wx = fist.xs[0]
        val wy = fist.ys[0]
        if (fistSince == 0L || hypot(wx - fistX, wy - fistY) > 0.03f) {
            fistSince = now
            fistX = wx
            fistY = wy
        } else if (now - fistSince >= HOLD_MS && now - lastHold >= COOLDOWN_MS) {
            lastHold = now
            fistSince = now
            onFistHold()
        }
    }

    private fun endPinch() {
        if (wasPinching) {
            wasPinching = false
            onPinchEnd()
        }
    }

    companion object {
        const val HOLD_MS = 1100L
        const val COOLDOWN_MS = 2000L
    }
}
