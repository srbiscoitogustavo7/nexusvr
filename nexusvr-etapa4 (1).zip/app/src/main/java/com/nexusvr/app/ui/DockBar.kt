package com.nexusvr.app.ui

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Barra de tarefas flutuante (abre segurando o punho fechado parado).
 * Funcionam: Configurações, Relógio (janela flutuante) e CENTRO (recentraliza a cabeça).
 * Os outros aplicativos aparecem como EM BREVE.
 */
class DockBar(
    context: Context,
    private val onSettings: () -> Unit,
    private val onOpen: (String) -> Unit,
    private val onRecenter: () -> Unit
) : LinearLayout(context) {

    private class AppItem(val name: String, val works: Boolean, val action: (() -> Unit)?)

    private val grid = GridLayout(context)
    private val clock = TextView(context)

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL

        grid.columnCount = 3
        grid.setPadding(dp(14), dp(14), dp(14), dp(14))
        grid.background = rounded(0xE6101826.toInt(), dp(18))
        grid.visibility = View.GONE
        val apps = listOf(
            AppItem("Configurações", true) { onSettings() },
            AppItem("Relógio", true) { onOpen("clock") },
            AppItem("Navegador", false, null),
            AppItem("Galeria", false, null),
            AppItem("Player de vídeo", false, null),
            AppItem("Gerenciador de apps", false, null)
        )
        for (app in apps) grid.addView(appCard(app))
        addView(
            grid,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { bottomMargin = dp(10) }
        )

        val bar = LinearLayout(context)
        bar.orientation = HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(10), dp(6), dp(10), dp(6))
        bar.background = rounded(0xE6101826.toInt(), dp(24))
        bar.addView(barButton("APPS") { toggleApps() })
        bar.addView(barButton("CONFIG") { onSettings() })
        bar.addView(barButton("CENTRO") { onRecenter() })
        clock.setTextColor(0xFFFFFFFF.toInt())
        clock.textSize = 15f
        clock.setPadding(dp(14), 0, dp(6), 0)
        bar.addView(clock)
        addView(bar)
        refreshClock()
    }

    fun refreshClock() {
        clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
    }

    private fun toggleApps() {
        grid.visibility = if (grid.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    private fun appCard(app: AppItem): Button {
        val b = Button(context)
        b.text = if (app.works) app.name else app.name + "\nEM BREVE"
        b.isAllCaps = false
        b.textSize = 14f
        b.isEnabled = app.works
        b.setTextColor(0xFFFFFFFF.toInt())
        b.background = rounded(if (app.works) 0xFF1E88E5.toInt() else 0xFF2A3342.toInt(), dp(14))
        b.layoutParams = GridLayout.LayoutParams().apply {
            width = dp(170)
            height = dp(90)
            setMargins(dp(6), dp(6), dp(6), dp(6))
        }
        b.setOnClickListener { app.action?.invoke() }
        return b
    }

    private fun barButton(label: String, action: () -> Unit): Button {
        val b = Button(context)
        b.text = label
        b.isAllCaps = false
        b.textSize = 14f
        b.setTextColor(0xFFFFFFFF.toInt())
        b.background = rounded(0xFF243247.toInt(), dp(16))
        b.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(48))
            .apply { setMargins(dp(4), 0, dp(4), 0) }
        b.setOnClickListener { action() }
        return b
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
