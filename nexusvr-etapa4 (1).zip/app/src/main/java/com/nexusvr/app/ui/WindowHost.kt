package com.nexusvr.app.ui

import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout

/**
 * Camada das janelas flutuantes. Cada janela tem uma posição em graus (ax, ay).
 * Com "janelas fixas no mundo" ligado, virar a cabeça move as janelas no sentido contrário.
 * O tamanho do campo de visão (opção Campo de visão) define quantos pixels vale cada grau.
 */
class WindowHost(context: Context) : FrameLayout(context) {

    var anchored = false
        set(v) {
            field = v
            layoutAll()
        }
    var fov = 90
        set(v) {
            field = v
            layoutAll()
        }

    private var headYaw = 0f
    private var headPitch = 0f
    private val wins = ArrayList<FloatingWindow>()

    private fun ppd(): Float = width / fov.coerceAtLeast(30).toFloat()
    private fun k(): Float = if (anchored) 1f else 0f

    fun setHead(yaw: Float, pitch: Float) {
        headYaw = yaw
        headPitch = pitch
        layoutAll()
    }

    fun open(kind: String, title: String, factory: () -> View) {
        val existing = wins.firstOrNull { it.kind == kind }
        if (existing != null) {
            existing.bringToFront()
            return
        }
        val w = FloatingWindow(context, kind, title, factory())
        w.ax = headYaw * k() + wins.size * 7f
        w.ay = -headPitch * k() + wins.size * 5f
        w.onClose = { close(it) }
        w.onResized = { post { layoutAll() } }
        w.onDragBy = { win, dx, dy -> dragBy(win, dx, dy) }
        wins.add(w)
        addView(w, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))
        w.post { layoutAll() }
    }

    private fun close(w: FloatingWindow) {
        wins.remove(w)
        removeView(w)
    }

    fun closeAll() {
        for (w in ArrayList(wins)) close(w)
    }

    fun centerX(w: FloatingWindow): Float = width / 2f + (w.ax - headYaw * k()) * ppd()
    fun centerY(w: FloatingWindow): Float = height / 2f + (w.ay + headPitch * k()) * ppd()

    /** Move a janela para que o seu centro fique em (cx, cy) na tela. */
    fun dragTo(w: FloatingWindow, cx: Float, cy: Float) {
        w.ax = ((cx - width / 2f) / ppd() + headYaw * k()).coerceIn(-100f, 100f)
        w.ay = ((cy - height / 2f) / ppd() - headPitch * k()).coerceIn(-70f, 70f)
        layoutAll()
    }

    private fun dragBy(w: FloatingWindow, dx: Float, dy: Float) {
        w.ax = (w.ax + dx / ppd()).coerceIn(-100f, 100f)
        w.ay = (w.ay + dy / ppd()).coerceIn(-70f, 70f)
        layoutAll()
    }

    fun layoutAll() {
        if (width == 0 || height == 0) return
        for (w in wins) {
            w.translationX = centerX(w) - w.width / 2f
            w.translationY = centerY(w) - w.height / 2f
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        layoutAll()
    }
}
