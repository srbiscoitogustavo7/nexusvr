package com.nexusvr.app.ui

import android.graphics.Rect
import android.view.View
import android.view.ViewGroup

/** Encontra o botão (ou a barra de arrastar de uma janela) sob o cursor. */
object UiHit {
    fun viewAt(group: View, localX: Float, localY: Float): View? {
        val loc = IntArray(2)
        group.getLocationOnScreen(loc)
        return hit(group, loc[0] + localX, loc[1] + localY)
    }

    private fun hit(v: View, x: Float, y: Float): View? {
        if (v.visibility != View.VISIBLE) return null
        val r = Rect()
        if (!v.getGlobalVisibleRect(r) || !r.contains(x.toInt(), y.toInt())) return null
        if (v is ViewGroup) {
            for (i in v.childCount - 1 downTo 0) {
                val c = hit(v.getChildAt(i), x, y)
                if (c != null) return c
            }
        }
        return if ((v.isClickable && v.isEnabled) || v.tag == "drag") v else null
    }
}
