package com.nexusvr.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import com.nexusvr.app.tracking.HandState

/**
 * Modo VR (VR Box, Cardboard...): a tela vira duas imagens, uma por olho.
 * Cada olho recebe câmera + menus + mãos. Com correção de lente, a imagem é deformada
 * em barril para compensar a lente (valor aproximado, ajustável no menu).
 */
class VrStereoView(context: Context) : View(context) {

    companion object {
        private const val COLS = 24
        private const val ROWS = 14
    }

    @Volatile private var frame: Bitmap? = null
    var hands: List<HandState> = emptyList()
    var fw = 1
    var fh = 1
    var ui: Bitmap? = null
    var style: Int = HandStyleRenderer.STYLE_SOLID
    var ipdMm = 63
    var zoom = 1f
    var lensK = 0f

    private var curX = 0f
    private var curY = 0f
    private var curOn = false
    private var curPinch = false
    private var eye: Bitmap? = null
    private val mesh = FloatArray((COLS + 1) * (ROWS + 1) * 2)
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)

    init {
        setWillNotDraw(false)
    }

    fun setFrame(b: Bitmap) {
        frame = b
        postInvalidate()
    }

    fun setCursor(x: Float, y: Float, pinch: Boolean, on: Boolean) {
        curX = x
        curY = y
        curPinch = pinch
        curOn = on
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.BLACK)
        val w = width
        val h = height
        if (w <= 0 || h <= 0) return
        val eyeW = w / 2
        var buf = eye
        if (buf == null || buf.width != eyeW || buf.height != h) {
            buf = Bitmap.createBitmap(eyeW, h, Bitmap.Config.ARGB_8888)
            eye = buf
        }
        composeEye(buf, -1f)
        present(canvas, buf, 0f, eyeW.toFloat(), h.toFloat())
        composeEye(buf, 1f)
        present(canvas, buf, eyeW.toFloat(), eyeW.toFloat(), h.toFloat())
    }

    private fun composeEye(buf: Bitmap, side: Float) {
        val c = Canvas(buf)
        c.drawColor(Color.BLACK)
        val w = buf.width.toFloat()
        val h = buf.height.toFloat()
        val shift = side * (ipdMm - 63) * w * 0.0015f
        c.save()
        c.translate(shift, 0f)
        val f = frame
        if (f != null) {
            val s = maxOf(w / f.width, h / f.height) * zoom
            c.save()
            c.translate((w - f.width * s) / 2f, (h - f.height * s) / 2f)
            c.scale(s, s)
            c.drawBitmap(f, 0f, 0f, null)
            c.restore()
        }
        ui?.let { c.drawBitmap(it, null, RectF(0f, 0f, w, h), null) }
        val map = HandStyleRenderer.mapFor(w, h, fw, fh, 0f, zoom)
        HandStyleRenderer.draw(c, hands, map, style)
        if (curOn) HandStyleRenderer.drawCursor(c, curX, curY, curPinch, map.sw)
        c.restore()
    }

    private fun present(c: Canvas, buf: Bitmap, left: Float, w: Float, h: Float) {
        if (lensK <= 0.001f) {
            c.drawBitmap(buf, left, 0f, null)
            return
        }
        var i = 0
        for (r in 0..ROWS) {
            val v = r.toFloat() / ROWS * 2f - 1f
            for (col in 0..COLS) {
                val u = col.toFloat() / COLS * 2f - 1f
                val k = 1f - lensK * (u * u + v * v)
                mesh[i++] = left + (u * k + 1f) * 0.5f * w
                mesh[i++] = (v * k + 1f) * 0.5f * h
            }
        }
        c.drawBitmapMesh(buf, COLS, ROWS, mesh, 0, null, 0, paint)
    }
}
