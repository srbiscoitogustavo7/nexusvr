# NEXUS VR - Etapa 4

- Menu inicial sobre a câmera: INICIAR, CONFIGURAÇÕES, SAIR. Tudo funciona com a pinça.
- Cursor: a ponta do indicador controla o cursor; pinça clica. Pinça na barra de título de uma janela arrasta.
- Punho fechado parado por 1 segundo abre a barra de tarefas (APPS, CONFIG, CENTRO e relógio).
  Funcionam: Configurações e Relógio (abre uma janela flutuante). Os outros aparecem como EM BREVE.
- Janelas flutuantes: arrastar (dedo ou pinça), − e + para tamanho, X para fechar.
- Cabeça (giroscópio): janelas fixas no mundo, sensibilidade e recentralizar (botão CENTRO).
- Câmera: frontal, traseira ou dupla (experimental, depende do celular).
- Modos de exibição: tela normal, VR Box 2.0, VR Box 1.0, Cardboard e óculos genérico.
  Duas imagens lado a lado, correção de lente, distância entre os olhos e campo de visão ajustáveis.
- Estilos de mão: pontos, ossos (esqueleto), mão sólida (estilo Quest, silhueta própria) e neon.
- Desempenho: GPU quando disponível, quadros descartados enquanto um quadro ainda processa,
  modo economia (1 quadro em cada 2) e resolução menor. FPS aparece no status.

Ainda não existe: aplicativos reais (navegador, galeria, vídeo), movimento da câmera virtual em 3D.
