package com.nexusvr.app

import android.content.Context
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner

/** Liga a câmera (frontal quando disponível) a um PreviewView usando CameraX. */
class CameraController(
    private val context: Context,
    private val owner: LifecycleOwner
) {
    fun start(
        previewView: PreviewView,
        lowResolution: Boolean,
        onStarted: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                val provider = future.get()
                val size = if (lowResolution) Size(640, 480) else Size(1280, 720)
                val preview = Preview.Builder()
                    .setTargetResolution(size)
                    .build()
                preview.setSurfaceProvider(previewView.surfaceProvider)

                val hasFront = provider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA)
                val selector = if (hasFront) {
                    CameraSelector.DEFAULT_FRONT_CAMERA
                } else {
                    CameraSelector.DEFAULT_BACK_CAMERA
                }

                provider.unbindAll()
                provider.bindToLifecycle(owner, selector, preview)
                onStarted(if (hasFront) "frontal" else "traseira")
            } catch (e: Exception) {
                onError(e.message ?: "erro desconhecido na câmera")
            }
        }, ContextCompat.getMainExecutor(context))
    }
}
