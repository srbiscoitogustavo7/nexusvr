package com.nexusvr.app

import android.content.Context

/** Guarda as configurações do app localmente (SharedPreferences). */
class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("nexus_settings", Context.MODE_PRIVATE)

    /** Sensibilidade do movimento da cabeça, em porcentagem (50..200). */
    var sensitivityPercent: Int
        get() = prefs.getInt("sensitivity", 100)
        set(v) = prefs.edit().putInt("sensitivity", v).apply()

    /** Distância interpupilar em milímetros (50..75). */
    var ipdMm: Int
        get() = prefs.getInt("ipd", 63)
        set(v) = prefs.edit().putInt("ipd", v).apply()

    /** Campo de visão em graus (60..120). */
    var fovDegrees: Int
        get() = prefs.getInt("fov", 90)
        set(v) = prefs.edit().putInt("fov", v).apply()

    /** Modo para celulares fracos: reduz a resolução da câmera. */
    var lowPerformance: Boolean
        get() = prefs.getBoolean("low_performance", false)
        set(v) = prefs.edit().putBoolean("low_performance", v).apply()
}
