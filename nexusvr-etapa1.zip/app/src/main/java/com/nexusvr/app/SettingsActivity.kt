package com.nexusvr.app

import android.graphics.Color
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private lateinit var column: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = SettingsStore(this)

        column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
        }

        addTitle("Configurações")

        addSeek("Sensibilidade da cabeça", 50, 200, store.sensitivityPercent, "%") {
            store.sensitivityPercent = it
        }
        addSeek("Distância interpupilar", 50, 75, store.ipdMm, " mm") {
            store.ipdMm = it
        }
        addSeek("Campo de visão", 60, 120, store.fovDegrees, "°") {
            store.fovDegrees = it
        }

        val lowSwitch = Switch(this).apply {
            text = "Modo celular fraco (câmera em baixa resolução)"
            setTextColor(Color.WHITE)
            isChecked = store.lowPerformance
            setOnCheckedChangeListener { _, checked -> store.lowPerformance = checked }
        }
        column.addView(lowSwitch)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(0xFF0B0F1A.toInt())
            addView(column)
        }
        setContentView(scroll)
    }

    private fun addTitle(text: String) {
        val title = TextView(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            textSize = 22f
            setPadding(0, 0, 0, 32)
        }
        column.addView(title)
    }

    private fun addSeek(
        label: String,
        minValue: Int,
        maxValue: Int,
        current: Int,
        unit: String,
        onChange: (Int) -> Unit
    ) {
        val caption = TextView(this).apply {
            setTextColor(Color.WHITE)
            text = "$label: $current$unit"
            setPadding(0, 24, 0, 0)
        }
        val bar = SeekBar(this)
        bar.max = maxValue - minValue
        bar.progress = current - minValue
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val value = progress + minValue
                caption.text = "$label: $value$unit"
                if (fromUser) onChange(value)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        column.addView(caption)
        column.addView(bar)
    }
}
