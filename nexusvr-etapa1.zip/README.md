# NEXUS VR - Etapa 1 (base do app)

Inclui: projeto Gradle, CameraX com preview da câmera frontal, tela de configurações
(sensibilidade, IPD, campo de visão, modo celular fraco) salvas localmente.
Ainda NÃO inclui: rastreamento de mãos, interface VR, sensores, modo headset (próximas etapas).

## Compilar no PC
Abra a pasta no Android Studio e clique em Run, ou Build > Build APK.

## Compilar na nuvem (GitHub Actions, grátis)
Veja o workflow em .github/workflows/build.yml. O APK sai em Actions > Artifacts.
